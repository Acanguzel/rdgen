from pathlib import Path
import json
import shutil
c=json.loads(Path('windesk/build-settings.json').read_text())
shutil.copyfile('windesk/icon.svg','flutter/assets/icon.svg')
def replace(file, old, new, required=True):
 p=Path(file); s=p.read_text(encoding='utf-8')
 if required and old not in s: raise RuntimeError(f'Missing branding target: {file}: {old}')
 p.write_text(s.replace(old,new), encoding='utf-8')
replace('libs/hbb_common/src/config.rs','rs-ny.rustdesk.com',c['serverIP'])
replace('libs/hbb_common/src/config.rs','OeVuKk5nlHiXp+APNn0Y3pC1Iwpwn44JGqrQCsWqmBw=',c['key'])
replace('src/common.rs','https://admin.rustdesk.com',c['apiServer'])
for file in ['Cargo.toml','libs/portable/Cargo.toml','flutter/windows/runner/Runner.rc']:
 replace(file,'RustDesk Remote Desktop','Windesk')
 replace(file,'Purslane Ltd','EVRENBIL',False)
 replace(file,'"RustDesk"','"Windesk"',False)
 replace(file,'rustdesk.exe','Windesk.exe',False)
replace('libs/portable/src/main.rs','const APP_PREFIX: &str = "rustdesk";','const APP_PREFIX: &str = "Windesk";')
replace('flutter/lib/desktop/pages/desktop_setting_page.dart','Purslane Ltd','EVRENBIL',False)
replace('flutter/lib/desktop/pages/desktop_home_page.dart','https://rustdesk.com/download','https://windesk.tr',False)
